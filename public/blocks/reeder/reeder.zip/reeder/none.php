
<div class="consult" style="color: #eaeaea; background-color: #01d084; padding: 5px">
    <h1>К сожалению у вас пока нет ни одного читательского пакета</h1>
    <p>Чтобы приобрести полную версию книги "Трещины" и получить подарок, выберите один из имеющихся пакетов.</p>
</div><br>

<div class="btn_program" style="width: 30%">
    <a href="/family/packages">
        <baton >Выбрать читательский пакет</baton>
    </a>
</div><br><br>

<!--<a href="/hudeem/freeConsult" >-->
<!--<div>-->
<!---->
<!--        <button class="blick btn_why mobile btn_program" style="margin-top: 10px; width: auto; height: 50px; background: gold">Заказать бесплатную консультацию</button>-->
<!---->
<!--</div>-->
<!--</a><br>-->