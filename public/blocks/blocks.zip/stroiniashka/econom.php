
<div class="consult" style="color: #eaeaea">
    <h1>Программа снижения веса "Эконом"</h1><br>

    <a href="/hudeem/video" style="margin-top: 10px">
        <button class="btn_why mobile" style="float: left; height: auto; margin-bottom: 20px; font-size: medium; font-weight: bold">Перейти к видеокурсу</button>
    </a>

    <?php require 'public/blocks/stroiniashka/consultant.php'?>

</div>