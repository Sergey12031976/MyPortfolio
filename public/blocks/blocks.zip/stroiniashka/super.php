
<div class="consult" style="color: #eaeaea">
    <h1>Программа снижения веса "СуперЭффект"</h1><br>

    <div style="background: #01d084; color: #ff5644; font-size: medium; font-weight: bold; padding: 2%">
        <p>Здесь будут указываться данные для подключения к видео конференции. Следите за расписанием.
        </p>
    </div>

    <a href="https://us05web.zoom.us/j/84784891999?pwd=NjNSeFJhWnFHUWN0aUU1dUlRSDRYUT09" target="page" style="margin-top: 10px">
        <button class="btn_why mobile" style="float: left; height: auto; margin-bottom: 20px; font-size: medium; font-weight: bold">Подключиться к видеоконференции</button>
    </a>
    <a href="/hudeem/video" style="margin-top: 10px">
        <button class="btn_why mobile" style="float: left; height: auto; margin-bottom: 20px; font-size: medium; font-weight: bold">Перейти к видеокурсу</button>
    </a>

    <?php require 'public/blocks/stroiniashka/consultant.php'?>

</div>