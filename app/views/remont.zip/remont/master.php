<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>JavaScript</title>
    <link rel="stylesheet" href="/public/css/remont.css">
<!--    <link rel="stylesheet" href="/public/css/main.css" charset="utf-8">-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" crossorigin="anonymous">
    <link rel="stylesheet" href="/public/css/slick.css">
</head>
<body>
<header>
    <span class="logo">VashMaster</span>
    <div class="nav">
        <a href="#">В начало</a>
        <a href="#">Про компанию</a>
        <a href="#">Услуги</a>
    </div>
    <span class="menu" id="show-menu">
      <i class="fas fa-bars"></i>
    </span>
</header>

<div id="hidden-menu" class="menu_mobile">
    <span class="close">
      <i class="fas fa-times"></i>
    </span>
    <h2>Меню</h2>
    <ul>
        <list><a href="#">Главная</a></list>
        <list><a href="#">Про компанию</a></list>
        <list><a href="#">Услуги</a></list>
    </ul>
</div>

<section class="full-page">
    <h1>VashMaster - ремонт без хлопот</h1>
    <h3>Пора делать ремонт? Закажите у нас и забудьте о нем. Мы все сделаем за вас сами.</h3>
    <a href="#know_more"><button>Узнай больше <i class="fas fa-arrow-right"></i></button></a>
    <a href="#measuring">
        <batton class="blick btn_why" style="width: 20%;
  height: 20px;
  background: gold;
  border-radius: 5px;
  border: 0;
  font-size: 14px;
  margin-left: 10px;
  color: purple;
  cursor: pointer;
  transition: all 600ms ease;
  padding: 10px 5px 10px 5px;">
            Заказать бесплатный замер
        </batton>
    </a>
</section>

<section class="features"><a name="know_more"></a>
    <div>
        <img src="../../public/img/remont/cool-icon.png" alt="">
        <h4>Удобно</h4>
        <p>Мы сами бесплатно посчитаем необходимые объемы материалов. Вам не придется переплачивать за лишние материалы или
            искать потом такие же, в случае нехватки. Поможем в поиске и покупке материалов. Проконсультируем по вопросам
            производителей, цен на материалы, сочетания цветов и дизайна</p>
    </div>
    <div>
        <img src="../../public/img/remont/cool-icon.png" alt="">
        <h4>Качественно</h4>
        <p>Высокий уровень профессионализма обеспечен не только знаниями и навыками, но и многолетним практическим опытом</p>
    </div>
    <div>
        <img src="../../public/img/remont/light-icon.png" alt="">
        <h4>Чисто</h4>
        <p>Вам не придется наводить порядок в доме после нашего ремонта. Мы сами обеспечим чистоту и порядок.</p>
    </div>
</section>

<section class="gallery">
    <h2>Результаты нашей работы:</h2>
    <div id="slider">
        <div><img src="https://bouw.ru/wp-content/uploads/2021/12/40.jpg" alt=""></div>
        <div><img src="https://st7.stpulscen.ru/images/product/144/707/491_big.jpg" alt=""></div>
        <div><img src="https://media.3dplitka.ru/CACHE/images/catalog/tubadzin/tubadzin-artemon/tubadzin-artemon.31cb28bdc858.jpg" alt=""></div>
        <div><img src="https://keramobum.ru/upload/bau/lb-ceramics/parizhanka2/parizhanka22.jpg" alt=""></div>
    </div>
</section>

<section class="bg-fixed"><a name="measuring"></a>
    <h3>Заказать бесплатный замер</h3>
    <form action="/contact" method="post" class="form-control">

            <input type="text" name="name" placeholder="Ваше имя" value="">

            <input type="email" name="email" placeholder="Ваш email" value=""><br>

            <input type="text" name="age" placeholder="Ваш номер телефона" value=""><br>

            <textarea name="message" placeholder="Введите сообщение" ></textarea><br>

        <button class="btn" id="send">Отправить</button>
    </form>
</section>

<footer>
    <div class="up-btn">
        <i class="fas fa-arrow-up"></i>
    </div>
    <p>Все права защищены &copy;</p>
    <div class="social">
        <div><i class="fab fa-youtube"></i></div>
        <div><i class="fab fa-facebook-f"></i></div>
        <div><i class="fab fa-twitter"></i></div>
    </div>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="/public/js/slick.min.js"></script>
<script src="/public/js/index.js"></script>
</body>
</html>
