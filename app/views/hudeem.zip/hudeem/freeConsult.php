<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Бесплатная консультация по снижению веса</title>
    <meta name="description" content="Закажите бесплатную консультацию, и мы дадим вам персональные рекомендации по снижению веса,
        а так же поможем выбрать оптимальную для вас программу эффективного снижения веса." />

    <link rel="stylesheet" href="/public/css/main.css" charset="utf-8">
    <link rel="stylesheet" href="/public/css/hudeem.css" charset="utf-8">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" crossorigin="anonymous">
    <link rel="icon" href="/public/img/logo.svg">
    <link rel="stylesheet" href="/public/css/form.css" charset="utf-8">
<!--    <link rel="stylesheet" href="/public/css/main.css?url=--><?//=mt_rand(0,100)?><!--" type="text/css" charset="utf-8">-->
<!--    <link rel="stylesheet" href="/public/css/form.css?url=--><?//=mt_rand(0,100000)?><!--" type="text/css" charset="utf-8">-->
</head>
<body>
<?php require_once 'public/blocks/vodasol.php'; ?>

<div class="container main">
    <h1>Бесплатная консультация</h1>

    <form action="freeConsult" method="post" class="form-control">

        <p style="color: #fafafa">Закажите бесплатную консультацию, и мы дадим вам персональные рекомендации по снижению веса,
            а так же поможем выбрать оптимальную для вас программу эффективного снижения веса.</p>

        <?php if(isset($_POST['message'])): ?>
            <div class="error" style="color: gold; font-size: larger; font-weight: bolder"><?=$data['message']?></div>
        <?php else: ?>
            <div class="error"></div>
        <?php endif; ?>
        <?php if(isset($_POST['name'])): ?>
            <input type="text" name="name" placeholder="Введите имя" value="<?=$_POST['name']?>">
        <?php else: ?>
            <input type="text" name="name" placeholder="Введите имя">
        <?php endif; ?>
        <?php if(isset($_POST['email'])): ?>
            <input type="email" name="email" placeholder="Введите email" value="<?=$_POST['email']?>"><br>
        <?php else: ?>
            <input type="email" name="email" placeholder="Введите email"><br>
        <?php endif; ?>
        <?php if(isset($_POST['age'])): ?>
             <input type="text" name="age" placeholder="Введите возраст" value="<?=$_POST['age']?>"><br>
        <?php else: ?>
             <input type="text" name="age" placeholder="Введите возраст"><br>
        <?php endif; ?>
        <p style="color: #fafafa">В поле для сообщения укажите предпочтительный для вас способ связи (skype, viber, whatsup),
            а так же ваш логин или номер телефона в данных мессенджерах, по которым наши консультанты смогут связаться с вами.</p>
        <?php if(isset($_POST['message'])): ?>
            <textarea name="message" placeholder="Введите сообщение" ><?=$_POST['message']?></textarea><br>
        <?php else: ?>
            <textarea name="message" placeholder="Введите сообщение"></textarea><br>
        <?php endif; ?>

        <button class="btn" id="send">Отправить</button>
    </form>
</div>

<?php require_once 'public/blocks/footer.php'; ?>
</body>
</html>