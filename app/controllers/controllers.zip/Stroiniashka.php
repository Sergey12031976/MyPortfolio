<?php
class Stroiniashka extends Controller {
    public function consultant() {
        $data = [];
        if(isset($_POST['name'])) {
//            $topic = $this->model('Consultant');
            $message = $this->model('Consultant');
            $message->setData($_POST['name'], $_POST['email'], $_POST['message']);

            $isValid = $message->validForm();
            if($isValid == "Сообщение отправлено") {

                $data['message'] = $message->addMessage();
                $data['message']=$message->mail();
            }
            else
                $data['message'] = $isValid;
        }

        $this->view('user/dashboard', $data);
    }

    public function noprogram() {
        $this->view('user/dashboard');
    }


    public function econom() {
        $this->view('contact/about');
    }

    public function standart() {

        $dateControl = $this->model('Program');
        $dateControl -> programNull();
        $this->view('user/dashboard', $dateControl -> programNull());
    }

    public function super() {

        $dateControl = $this->model('Program');
        $dateControl -> programNull();
        $this->view('user/dashboard', $dateControl -> programNull());
    }

}